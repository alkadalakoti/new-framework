import subprocess
import os
import csv
import re
from time import sleep
from shlex import split
from Utils.DeviceUtils import DeviceUtils
from Utils.LoggerReporter import Reporter, Logger
import uiautomator2 as u
from Utils.Crash_Anr_Parser import Crash_Anr_Parser

get_all_activity_app = 'com.radisys.getactivity/.MainActivity'
activity_filename_dev = '/sdcard/Documents/GetActivity/activity_name.csv'
activity_filename = 'activity_name.csv'
activity_exclude_list = ['com.radisys.getactivity/.MainActivity',
                         'com.android.camera2/com.android.camera.CameraLauncher']
Num_Of_Iterations = 0
WarmLaunch = False
ColdLaunch = False
devUtils = None
logObj = None
reporterObj = None

def format_values(alt_values):
    formatted_str = ''
    for i in alt_values:
        formatted_str = formatted_str + str(i) + "\n"
    return formatted_str


def startTest():
    l = ['Resources','app-debug.apk']
    apk_path = os.path.join(os.getcwd(),*l)
    g_cmd = "adb -s " + str(dut_serial) + "  install -r -g -t \""+str(apk_path)+"\""
    os.system(g_cmd)
    sleep(10)

    logObj.logMsg("info", "A", "Getactivity list APK installed..")

    g_cmd = "adb -s " + str(dut_serial) + " shell am start " + str(get_all_activity_app)
    os.system(g_cmd)
    sleep(5)
    logObj.logMsg("info", "A", "Getactivity app launched..")

    os.system("adb -s " + str(dut_serial) + " shell input keyevent 4")
    sleep(3)
    os.system("adb -s " + str(dut_serial) + " shell input keyevent 4")
    sleep(3)
    os.system("adb -s " + str(dut_serial) + " shell input keyevent KEYCODE_HOME")
    sleep(3)

    pull_cmd = "adb -s " + str(dut_serial) + " pull " + str(activity_filename_dev) + " ."
    os.system(pull_cmd)
    sleep(5)
    logObj.logMsg("info", "A", "pull activity list file...")

    if not os.path.exists(activity_filename):
        logObj.logMsg("error", "A", "Failed to pull activity names file...")
        exit(0)
    with open(activity_filename) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        j = 1
        for i in csv_reader:
            logObj.logMsg("info", "A", "Start ===================================================== " + str(j))
            logObj.logMsg("info", "A", "parsed str " + str(i))
            if len(i) == 2:
                tmp = i[1].split("cmp=")[1]
                tmp = tmp.split("}")[0]
                logObj.logMsg("info", "A", "parsed str " + str(tmp))
                if bool(tmp):
                    if bool(tmp.strip()):
                        tmp = tmp.strip()
                        logObj.logMsg("info", "A", "App Name to Launch is :" + str(i[0]))
                        logObj.logMsg("info", "A", "Activity to Launch is :" + str(tmp))
                        if tmp in activity_exclude_list:
                            logObj.logMsg("info", "A", "This Activity name is present exclude list..")
                        else:
                            print("Launch ", tmp)
                            iter_val = []

                            for l in range(Num_Of_Iterations):
                                try:
                                    if WarmLaunch:
                                        am_start_op = subprocess.check_output(
                                            split("adb -s " + str(dut_serial) + " shell am start -W " + str(tmp)),
                                            stderr=subprocess.STDOUT, timeout=30)
                                    else:
                                        am_start_op = subprocess.check_output(
                                            split("adb -s " + str(dut_serial) + " shell am start -S -W " + str(tmp)),
                                            stderr=subprocess.STDOUT, timeout=30)
                                    op = am_start_op.decode()
                                    sleep(4)
                                    logObj.logMsg("info", "A", "Launch time O/p :" + str(op))
                                    if op != '':
                                        op = op.split("\n")
                                        for z in op:
                                            match_object = re.match(r'TotalTime: (\d+)', z)

                                            if bool(match_object):
                                                logObj.logMsg("info", "A",
                                                              "Regex Match success and the total time is :" + str(
                                                                  match_object.group(1)))
                                                iter_val.append(match_object.group(1))
                                    else:
                                        iter_val.append(0)
                                    logObj.collectMemInfo(os.path.join(os.environ.get('EduOs_Meminfo_path'),
                                                                       "meminfo_" + str(i[0]) + "_" + str(l) + ".txt"))
                                except subprocess.TimeoutExpired:
                                    logObj.logMsg("error", "A", 'Timeout, No output within 30 seconds ....')
                                    iter_val.append(0)
                                finally:
                                    os.system("adb -s " + str(dut_serial) + " shell input keyevent 4")
                                    sleep(3)

                                    os.system("adb -s " + str(dut_serial) + " shell input keyevent 4")
                                    sleep(3)

                                    os.system("adb -s " + str(dut_serial) + " shell input keyevent KEYCODE_HOME")
                                    sleep(3)
                            devUtils.InitialSetup()
                            sum = 0
                            logObj.logMsg("info", "A", "All ALT values :" + str(iter_val))
                            for z in iter_val:
                                sum = sum + int(z)
                            if len(iter_val) != Num_Of_Iterations:
                                appnd_val = Num_Of_Iterations - len(iter_val)
                                for l in range(appnd_val):
                                    iter_val.append(0)
                                avg_val = sum / len(iter_val)
                            else:
                                avg_val = sum / len(iter_val)
                            logObj.logMsg("info", "A", "average value is " + str(avg_val))
                            values_str = format_values(iter_val)
                            reporterObj.writeReportFile({'Serial_No.': j, 'Application_Name': i[0], 'ActivityName': tmp,
                                                         'Launch_Time_Values': values_str, 'Average_value': avg_val})
                            logObj.logMsg("info", "A",
                                          "END ================================================================" + str(
                                              j))
                            j = j + 1
                else:
                    print(tmp)
                    logObj.logMsg("info", "A", 'Activity Name is empty, try another from list..')
            else:
                logObj.logMsg("info", "A", "AppInfo list is not proper..")


def printUsage():
    print("\r\n  Usage:\r\n\t1.Provide \"1\" for WARM launch.\r\n\t2.Provide \"2\" for COLD launch.")


def start_crash_anr_reporter():
    try:
        obj_log = Crash_Anr_Parser(dut_serial)
        obj_log.daemon = True
        logObj.logMsg("info", "A", "Crash-ANR parser started ...")
        obj_log.start()
        return obj_log
    except KeyboardInterrupt:
        obj_log.stop_parser()


def stop_crash_anr_reporter(obj_log):
    obj_log.stop_parser()


if __name__ == "__main__":
    os.system("adb devices")
    dut_serial = input("Please enter the Serial ID of the DUT : ")
    dut_serial = dut_serial.strip()

    os.environ['EduOs_Dev_A'] = dut_serial
    reporterObj = Reporter()
    logObj = Logger()
    devUtils = DeviceUtils()

    if not devUtils.checkAdbDevice(dut_serial):
        print("Device " + str(dut_serial) + " not found !!!!!!!!!!")
        exit(0)

    printUsage()

    try:

        while True:
            alt_mode_input = input()
            if (alt_mode_input == '1') or (alt_mode_input == '2'):
                reporterObj.create_report_folders()
                if int(alt_mode_input) == 1:
                    logObj.logMsg("info", "A", "Start Warm Launch .............")
                    WarmLaunch = True
                else:
                    logObj.logMsg("info", "A", "Start Cold Call.............")
                    ColdLaunch = True
                break
            else:
                print("\r\n  Please provide valid input .!")
                printUsage()

        Num_Of_Iterations = int(input("Please Enter the Number of Iterations to run for ALT : "))
        reporterObj.createReportFile()
        devUtils.InitialSetup()
        devUtils.registerPermissionWatcher()
        crashAnrObj = start_crash_anr_reporter()
        startTest()

    finally:
        stop_crash_anr_reporter(crashAnrObj)
