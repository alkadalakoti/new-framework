import queue
import subprocess
import threading
from shlex import split
import os
from builtins import any as b_any
from Utils.LoggerReporter import Logger

CRASH_STRING_1 = 'FATAL EXCEPTION'
ANR_STRING_1 = 'ANR in'
error_list = {'crash_list':[], 'anr_list':[]}


class AsynchronousFileReader(threading.Thread):

    def __init__(self, fd, queue_tmp ):
        assert isinstance(queue_tmp, queue.Queue)
        assert callable(fd.readline)
        threading.Thread.__init__(self)
        self._fd = fd
        self._queue = queue_tmp
        self.is_running = True

    def run(self):
        '''The body of the tread: read lines and put them on the queue.'''
        for line in iter(self._fd.readline, ''):
            if not self.is_running:
                print("Stop queue")
                return
            self._queue.put(line)

    def stopFlag(self):
        print("AsynchronousFileReader Stop call..")
        self.is_running = False

    def eof(self):
        '''Check whether there is no more content to expect.'''
        # return not self.is_alive() and self._queue.empty()
        return not self.is_alive()


class Crash_Anr_Parser(threading.Thread):
    failure_l = None
    process_t = None
    stdout_reader = None

    def __init__(self, dut_serial):
        self.isrunning = True
        self.dut_serial = dut_serial
        threading.Thread.__init__(self)
        self.log_obj = Logger()

    def run(self):
        global stdout_reader, error_list

        crash_file = os.environ.get('EduOs_Crash_file')
        anr_file = os.environ.get('EduOs_Anr_file')

        if not os.path.exists(crash_file):
            print("Crash file not exists ..")
            with open(crash_file, 'w+'):
                pass

        if not os.path.exists(crash_file):
            print("Anr file not exists ..")
            with open(anr_file, 'w+'):
                pass

        process_t = subprocess.Popen(split("adb -s "+str(self.dut_serial)+" logcat -b all "), stdout=subprocess.PIPE, shell=True)
        stdout_queue = queue.Queue()
        stdout_reader = AsynchronousFileReader(process_t.stdout, stdout_queue)
        stdout_reader.daemon = True
        stdout_reader.start()

        while True:
            if not self.isrunning:
                print("Return :",self.isrunning)
                return

            if stdout_reader.eof():
                print("Not alive ..")
                return

            line = stdout_queue.get()
            line = line.decode()
            line = line.strip()

            if CRASH_STRING_1 in line:
                crashListTmp = error_list['crash_list'].copy()
                crashListTmp.append(line)
                print(line)

                with open(crash_file,'r+') as f:
                    lines = f.readlines()
                    if not b_any(line in x.strip() for x in lines):
                        f.write(line+str("\n"))
                        self.log_obj.collect_ANR_Tombstones()

            elif ANR_STRING_1 in line:
                anrListTmp = error_list['crash_list'].copy()
                anrListTmp.append(line)
                print(line)

                with open(anr_file,'r+') as f:
                    lines = f.readlines()
                    if not b_any(line in x.decode() for x in lines):
                        f.write(line+str("\n"))
                        self.log_obj.collect_ANR_Tombstones()


    def stop_parser(self):
        stdout_reader.stopFlag()
        self.isrunning = False
        print("Stop everything log analyzer ...")





