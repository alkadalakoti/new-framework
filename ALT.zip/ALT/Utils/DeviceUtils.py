import os
from time import sleep
import subprocess
import uiautomator2 as u
from shlex import split
import constants

class DeviceUtils:

    def __init__(self):
        self.dut_serial = os.environ.get('EduOs_Dev_A')
        self.ui_driver = u.connect(self.dut_serial)

    def take_screenshot(self, test_id):
        """Capture the screenshot and store it into .
        Reports-->Report_currentdate_name.png.
        """
        cmd = "adb -s  " + str(self.dut_serial) + " shell screencap -p '/data/local/tmp/ " + str \
            (test_id + ".png'")
        print("take screenshot cmd : " + str(cmd))
        os.system(cmd)
        cmd_pull = "adb -s  " + str(self.dut_serial) + " pull \"/data/local/tmp/ " + str \
            (test_id + ".png\"") + " \" " + str(os.path.abspath(os.environ.get('EduOs_Screenshot_path'))) + "\""
        os.system(cmd_pull)
        print("Pull screenshot cmd : " + str(cmd_pull))
        cmd_dlt = "adb -s  " + str(self.dut_serial) + " shell rm -rf '/data/local/tmp/ " + str \
            (test_id + ".png'")
        os.system(cmd_dlt)
        print("Delete screenshot cmd :" + str(cmd_dlt))
        print("Screenshot captured successfully..")

    def clickOnView(self, UiObject):
        """Clicks on UI object"""
        clickFlag = False
        for i in range(30):
            if UiObject.exists():
                UiObject.click()
                sleep(1)
                print("clicked on view ", UiObject)
                clickFlag = True
                break
            else:
                print("Waiting for UiObject ", UiObject)
                sleep(1)
        return clickFlag

    def checkAdbDevice(self,dut_serial):
        flag = False
        check_device = subprocess.Popen(split("adb -s " + str(dut_serial) + " shell echo ==SUCCESS=="),
                                        stdout=subprocess.PIPE,
                                        stderr=subprocess.STDOUT)
        op = check_device.stdout.read().decode().strip()
        if op == "==SUCCESS==":
            flag = True
        return flag

    def registerPermissionWatcher(self,):
        '''This is UI watcher function to handle runtime permissions'''
        self.ui_driver.watcher("PERMISSION_WATCHER").when(xpath="//*[@text = 'ALLOW']").click()
        sleep(2)
        self.ui_driver.watcher.start()

    def InitialSetup(self,):
        os.system("adb -s " + str(self.dut_serial) + " shell input keyevent KEYCODE_HOME")
        sleep(2)
        self.clickOnView(self.ui_driver(resourceId=constants.Resource_id.recent_apps))
        sleep(3)

        if self.ui_driver(text=constants.Text.clear_all).exists():
            self.clickOnView(self.ui_driver(text=constants.Text.clear_all))
            sleep(3)
        os.system("adb -s " + str(self.dut_serial) + " shell svc power stayon true")