import os
from datetime import datetime
import logging
import sys
from Utils.DeviceUtils import DeviceUtils
import csv
import subprocess
import threading
from shlex import split
from threading import Timer

class Reporter:

    def __init__(self):
        self.csv_report_fields = ['Serial_No.','Application_Name','ActivityName','Launch_Time_Values','Average_value']
        self.devUtils = DeviceUtils()

    def createLogFolder(self):
        """Creating Log folder inside the report folder."""
        logs_path = os.path.join(os.environ.get('EduOs_Report_path'),"Logs")
        os.mkdir(logs_path)
        path = os.path.abspath(logs_path)
        return path

    def createAllLogsFolder(self):
        os.environ['EduOs_Logcat_path'] = logs_path = os.path.join(os.environ.get('EduOs_Log_path'), "Logcat_logs")
        os.mkdir(logs_path)

        os.environ['EduOs_Meminfo_path'] = meminfo_path = os.path.join(os.environ.get('EduOs_Log_path'), "MemInfo")
        os.mkdir(meminfo_path)

        os.environ['EduOs_Tombstones_path'] = tombstones_path = os.path.join(os.environ.get('EduOs_Log_path'), "Tombstones")
        os.mkdir(tombstones_path)

        os.environ['EduOs_ANR_path'] = anr_tracespath = os.path.join(os.environ.get('EduOs_Log_path'), "ANR_traces")
        os.mkdir(anr_tracespath)

    def create_report_folders(self):
        """Create report folder with respect to current date and time."""
        os.environ['EduOs_Report_path'] = self.createReportFolder()
        os.environ['EduOs_Screenshot_path'] = self.createScreenshotFolder()
        os.environ['EduOs_Log_path'] = self.createLogFolder()
        self.createAllLogsFolder()
        self.createCrashAnrLoggerFiles()

    def createReportFolder(self):
        """Create Report Folder by using date and time."""
        time_now = datetime.now().strftime("%d_%m_%Y-%H_%M_%S")
        reportfolder = "Output_"+str(time_now)
        report_path_list = ['Reports',reportfolder]
        reportpath = os.path.join(os.getcwd(), *report_path_list)
        reportpath = os.path.abspath(reportpath)
        os.mkdir(reportpath)
        return reportpath

    def createReportFile(self):
        os.environ['EduOs_report_file'] = report_file = os.path.join(os.environ.get('EduOs_Report_path'), "ALTSummaryData.csv")
        with open(report_file, 'w+'):
            pass

    def createCrashAnrLoggerFiles(self,):
        os.environ['EduOs_Crash_file'] = crash_file = os.path.join(os.environ.get('EduOs_Report_path'),"crash_list.txt")
        os.environ['EduOs_Anr_file'] = anr_file = os.path.join(os.environ.get('EduOs_Report_path'), "anr_list.txt")
        os.environ['EduOs_Logger_file'] = logger_file = os.path.join(os.environ.get('EduOs_Report_path'), "console.log")
        with open(crash_file, 'w+'):
            pass
        with open(anr_file, 'w+'):
            pass
        with open(logger_file, 'w+'):
            pass


    def createScreenshotFolder(self):
        """Create Report Folder by using date and time."""
        screenshot_path = os.path.join(os.environ.get('EduOs_Report_path'),"Screenshot")
        os.mkdir(screenshot_path)
        path = os.path.abspath(screenshot_path)
        return path

    def check_header(self,):
        with open(os.environ.get('EduOs_report_file')) as f:
            first = f.read(1)
        return first not in '.-0123456789'

    def writeReportFile(self,data):
        report_file = os.environ.get('EduOs_report_file')
        if not os.path.exists(report_file):
            with open(report_file, 'w') as f_object:
                writer_object = csv.DictWriter(f_object, fieldnames=self.csv_report_fields)
                writer_object.writeheader()

        with open(report_file, 'a') as f_object:
            writer_object = csv.DictWriter(f_object, fieldnames=self.csv_report_fields)
            if not self.check_header():
                writer_object.writeheader()
            writer_object.writerows([data])


class Logger:

    def __init__(self):
        self.logger = logging.getLogger("DegAutomation")
        self.LOG_TAG = "DegAutomation"
        self.logger.setLevel(logging.INFO)
        self.isLogcatRunning = True
        self.dut_serial = str(os.environ.get('EduOs_Dev_A'))

    def get_logger(self):
        if not self.logger.handlers:
            formatter = logging.Formatter('%(asctime)s | %(levelname)s | %(message)s')
            stdout_handler = logging.StreamHandler(sys.stdout)
            stdout_handler.setLevel(logging.DEBUG)
            stdout_handler.setFormatter(formatter)
            file_handler = logging.FileHandler(os.environ.get('EduOs_Logger_file'))
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
            self.logger.addHandler(stdout_handler)
        return self.logger

    def logMsg(self,log_type,Device,value):
        log_obj=self.get_logger()

        if log_type == "error":
            log_obj.error(value)
        elif log_type == "debug":
            log_obj.debug(value)
        elif log_type == "info":
            log_obj.info(value)
        elif log_type == "warn":
            log_obj.warning(value)
        if Device == "A":
            cmd = "adb -s "+str(os.environ.get('EduOs_Dev_A'))+" shell log -t "+str(self.LOG_TAG)+" \"\"\""+str(value)+"\"\"\""
            os.system(cmd)
        if Device == "B":
            cmd = "adb -s "+str(os.environ.get('EduOs_Dev_B'))+" shell log -t "+str(self.LOG_TAG)+" \"\"\""+str(value)+"\"\"\""
            os.system(cmd)

    def processAndSaveLogs(self, log_proc, testcase_name):
        while True:
            if not self.isLogcatRunning:
                print("Stopping logcat collection ..")
            logcat_file = os.path.join(os.environ.get("EduOs_Log_path"), str(testcase_name) + ".txt")

            if not os.path.exists(logcat_file):
                with open(logcat_file, 'w+', encoding='utf-8') as f1:
                    f1.write(str(" "))

            for line in iter(log_proc.stdout.readline, b''):
                with open(logcat_file, 'a+', encoding='utf-8') as f:
                    f.write(str(line.decode()))


    def startLogcat(self, serial, TC_Name):
        process_t = subprocess.Popen(split("adb -s " + str(serial) + " logcat -b all "), stdout=subprocess.PIPE,
                                     shell=True)
        t = threading.Thread(target=self.processAndSaveLogs, args=(process_t, TC_Name))
        t.daemon = True
        t.start()


    def stopLogcat(self):
        print("Logcat Stop call..")
        self.isLogcatRunning = False


    def collectLogcatLogs(self,logcat_file):
        p = subprocess.Popen(split('adb -s ' + str(self.dut_serial) + ' logcat -b all'), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        kill = lambda process: process.kill()
        log_timer = Timer(20, kill, [p])
        log_timer.start()

        if not os.path.exists(logcat_file):
            with open(logcat_file, 'w+', encoding='utf-8') as f1:
                f1.write(str(" "))

        for line in iter(p.stdout.readline, b''):
            with open(logcat_file, 'a+', encoding='utf-8') as f:
                f.write(str(line.decode()))


    def collectMemInfo(self, mem_info_file):
        p = subprocess.Popen(split('adb -s ' + str(self.dut_serial) + ' shell dumpsys meminfo'), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

        if not os.path.exists(mem_info_file):
            with open(mem_info_file, 'w+', encoding='utf-8') as f1:
                f1.write(str(" "))

        for line in iter(p.stdout.readline, b''):
            with open(mem_info_file, 'a+', encoding='utf-8') as f:
                f.write(str(line.decode()))

    def collect_ANR_Tombstones(self):
        time_now = datetime.now().strftime("%d_%m_%Y-%H_%M_%S")
        tombstone_path = os.path.join(os.environ.get('EduOs_Tombstones_path'), str(time_now))
        anr_path = os.path.join(os.environ.get('EduOs_ANR_path'),str(time_now))

        os.mkdir(tombstone_path)
        os.mkdir(anr_path)

        os.system('adb -s ' + str(self.dut_serial) + ' pull /data/tombstones/* '+str(tombstone_path))

        os.system(
            'adb -s ' + str(self.dut_serial) + ' pull /data/ANR/* ' + str(anr_path))

        os.system(
            'adb -s ' + str(self.dut_serial) + ' shell rm -rf /data/tombstones/* ')

        os.system(
            'adb -s ' + str(self.dut_serial) + ' pull rm -rf /data/tombstones/* ')








