
from msilib.schema import Class


class Resource_id:
    window_caption = "android:id/caption"
    minimize_app = "android:id/minimize_window"
    maximize_app = "android:id/maximize_window"
    close_app = "android:id/close_window"
    app_Name = "android:id/app_Name"
    recent_apps = "com.android.systemui:id/recent_apps"
    recent_app_thumbnail = "com.android.systemui:id/task_view_thumbnail"
    task_stack_view = "com.android.systemui:id/task_stack_view"

class Text:
    clear_all = "Clear all"
    Running_apps = "Running Apps"
    No_running_apps = "No running apps"